//
//  ViewController.swift
//  MyAdventure
//
//  Created by Meagan Williams.
//

import UIKit

class ViewController: UIViewController {
    
    //creating and initializing int to track levels
    var lvl : Int = 1
    //names of levels
    var fir = FirstLvl()
    var sec = SecondLvl()
    var third = ThirdLvl()
    

    @IBOutlet weak var story: UILabel!
    
    @IBOutlet weak var pathOne: UIButton!
    
    @IBOutlet weak var pathTwo: UIButton!
    //classes
    class FirstLvl {
        //beginning of journey
        func Begin() -> String{
            return "You found a winning lottery ticket!"
        }
    }
    class SecondLvl {
        //find winner
        func FindWinner() -> String{
            return "You decide to look for the winner"
        }
        func KeepTicket() -> String{
            //keep ticket to yourself and end game
            return "You are arrested [End ADVENTURE]"
        }
    }
    class ThirdLvl{
        //check alley
        func CheckAlley() -> String{
            return "You found the winner. You won!"
        }
        //check building
        func CheckBuilding() ->String{
            return "Someone ran away with the ticket![END]"
        }
    }
    
    //logic
    
    @IBAction func pathOneLogic(_ sender: UIButton) {
        if(lvl == 1){
            story.text = sec.FindWinner()
            pathOne.setTitle("Check Alley", for: .normal)
            pathTwo.setTitle("Check Building", for: .normal)
            lvl += 1
        }
        else if(lvl == 2){
            story.text = third.CheckAlley()
            pathOne.setTitle("", for: .normal)
            pathTwo.setTitle("", for: .normal)
            lvl += 100
        }
    }
    
    @IBAction func pathTwoLogic(_ sender: UIButton) {
        if(lvl == 1){
            story.text = sec.KeepTicket()
            pathOne.setTitle("", for: .normal)
            pathTwo.setTitle("", for: .normal)
            lvl += 100
            
        }
        else if(lvl == 2){
            story.text = third.CheckBuilding()
            pathOne.setTitle("", for: .normal)
            pathTwo.setTitle("", for: .normal)
            lvl += 100
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        story.text = fir.Begin()
        pathOne.setTitle("You decide to look for the winner since it is the right thing to do", for: .normal)
        pathTwo.setTitle("You try to claim the ticket for yourself but you are arrested [End ADVENTURE]", for: .normal)
    }

    
}

